class Oblig4 {
	public static void main(String[] args) {
		new Legekontor();
	}	
} // end Oblig4

interface Avtale {
	int hentAvtaleNr();

} // end AvtaleLege

interface Lik {
	boolean samme(String navn);

} // end Lik